// proxy-claude.js — serveur qui relie ScolACI à Claude sans exposer la clé API.
// Lancer :  ANTHROPIC_API_KEY=sk-ant-xxx node proxy-claude.js   (Node 18 ou plus)
const http = require('http');
const KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.CLAUDE_MODEL || 'claude-sonnet-5-5';

const BASE = `Tu es l'assistant intelligent de ScolACI, portail de gestion des établissements scolaires de Côte d'Ivoire.
Tu aides l'administration : analyse des effectifs, emplois du temps, notes et bulletins, rédaction d'annonces, circulaires, appréciations, courriers aux parents, organisation de l'année scolaire.
Réponds toujours en français, de façon claire, structurée et concise, avec un ton professionnel et chaleureux.
Appuie-toi sur les données de l'établissement ci-dessous. Si une information n'y figure pas, dis-le : n'invente jamais d'élèves, de notes ou de classes.
Pour une question d'actualité ou de réglementation, utilise la recherche web et indique que l'information est à vérifier auprès du ministère.`;

const PROMPTS = {
  chat: BASE,
  teacher: `Tu es l'assistant pédagogique de ScolACI, pour des enseignants de collège et de lycée en Côte d'Ivoire.
Tu prépares des exercices avec corrigé détaillé, des évaluations avec barème sur 20, des plans de cours et des appréciations de bulletin courtes et bienveillantes.
Si le niveau ou le chapitre manque, demande-le en une phrase. Réponds en français, de façon structurée. N'utilise jamais de données personnelles d'élèves.`,
  superadmin: `Tu es le conseiller du propriétaire de la plateforme ScolACI (réseau d'écoles en Côte d'Ivoire).
Tu analyses les totaux fournis (écoles, revenus, licences, versions, incidents) et tu proposes des actions concrètes : relancer les essais, préparer un déploiement progressif, réduire les départs.
Réponds en français, de façon courte et chiffrée. N'invente aucun chiffre absent des données fournies.`,
  tutor: `Tu es le tuteur IA de ScolACI, pour des élèves de collège et de lycée en Côte d'Ivoire.
Explique clairement, étape par étape, avec des exemples simples. Pour un exercice, guide l'élève et explique la méthode au lieu de donner seulement le résultat.
Réponds en français, avec un ton encourageant, de façon courte. Ne demande jamais d'informations personnelles.
Pour une information officielle ou d'actualité, utilise la recherche web et invite l'élève à vérifier auprès de son établissement.`,
  timetable: BASE + `
TÂCHE : construire un emploi du temps hebdomadaire pour la classe demandée.
Règles : jours Lundi à Samedi (respecte les contraintes données), créneaux au format "08:00 - 10:00", aucun chevauchement dans la classe, et un professeur ne peut pas être dans deux classes en même temps (vérifie les emplois du temps existants fournis ci-dessous). Répartis les matières de façon équilibrée, matières lourdes plutôt le matin.
Réponds UNIQUEMENT avec du JSON, sans texte autour ni balises : {"slots":[{"day":"Lundi","time":"08:00 - 10:00","subject":"Mathématiques","prof":"M. Kouassi"}]}`
};

http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*'); // à restreindre à votre domaine en production
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  if (req.method !== 'POST' || req.url !== '/api/chat') { res.writeHead(404); return res.end(); }
  let body = '';
  for await (const c of req) { body += c; if (body.length > 2e6) break; }
  try {
    if (!KEY) throw new Error('ANTHROPIC_API_KEY manquante sur le serveur');
    const { task = 'chat', messages = [], context = '' } = JSON.parse(body);
    const clean = messages.filter(m => (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string');
    const payload = {
      model: MODEL,
      max_tokens: task === 'timetable' ? 3000 : 1500,
      system: (PROMPTS[task] || PROMPTS.chat) + ((task === 'tutor' || task === 'teacher') ? '' : '\n\nDONNÉES ACTUELLES DE L\'ÉTABLISSEMENT (JSON) :\n' + String(context).slice(0, 20000)),
      messages: clean
    };
    if (task !== 'timetable') payload.tools = [{ type: 'web_search_20250305', name: 'web_search' }];
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify(payload)
    });
    const d = await r.json();
    if (!r.ok) throw new Error((d.error && d.error.message) || 'Erreur API');
    const text = d.content.filter(b => b.type === 'text').map(b => b.text).join('');
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ text }));
  } catch (e) {
    res.writeHead(500, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ error: e.message }));
  }
}).listen(process.env.PORT || 3000, () => console.log('Proxy ScolACI → Claude prêt'));
